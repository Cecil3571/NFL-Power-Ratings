import json
from datetime import datetime
from typing import Dict, List, Optional, Tuple

import pandas as pd
import pytz
import requests
from apscheduler.schedulers.background import BackgroundScheduler
from apscheduler.triggers.cron import CronTrigger
from bs4 import BeautifulSoup
from fastapi import FastAPI, HTTPException, Query
from fastapi.responses import JSONResponse, PlainTextResponse, HTMLResponse
from fastapi.templating import Jinja2Templates
from fastapi import Request

# ----------------------------
# Config
# ----------------------------
TZ = pytz.timezone("America/New_York")
ELO_TO_POINTS_DIVISOR = 25.0  # convert Elo diff to points
TARGET_URLS = [
    "https://www.nfeloapp.com/nfl-power-ratings/",
    "https://www.nfeloapp.com/",
]
PFR_SEASON_DEFAULT = datetime.now(TZ).year  # override via query if needed
DATA_PATH = "ratings.json"

# Team name normalization (nfelo -> 3-letter codes)
TEAM_ALIASES: Dict[str, str] = {
    "Arizona Cardinals": "ARI", "Atlanta Falcons": "ATL", "Baltimore Ravens": "BAL",
    "Buffalo Bills": "BUF", "Carolina Panthers": "CAR", "Chicago Bears": "CHI",
    "Cincinnati Bengals": "CIN", "Cleveland Browns": "CLE", "Dallas Cowboys": "DAL",
    "Denver Broncos": "DEN", "Detroit Lions": "DET", "Green Bay Packers": "GB",
    "Houston Texans": "HOU", "Indianapolis Colts": "IND", "Jacksonville Jaguars": "JAX",
    "Kansas City Chiefs": "KC", "Las Vegas Raiders": "LV", "Los Angeles Chargers": "LAC",
    "Los Angeles Rams": "LAR", "Miami Dolphins": "MIA", "Minnesota Vikings": "MIN",
    "New England Patriots": "NE", "New Orleans Saints": "NO", "New York Giants": "NYG",
    "New York Jets": "NYJ", "Philadelphia Eagles": "PHI", "Pittsburgh Steelers": "PIT",
    "San Francisco 49ers": "SF", "Seattle Seahawks": "SEA", "Tampa Bay Buccaneers": "TB",
    "Tennessee Titans": "TEN", "Washington Commanders": "WAS",
}

# PFR uses different 3-letter abbreviations on week pages; map to our codes
PFR_ABBR_TO_CODE: Dict[str, str] = {
    # NFC
    "ARI": "ARI", "ATL": "ATL", "DAL": "DAL", "NYG": "NYG", "PHI": "PHI", "WAS": "WAS",
    "CHI": "CHI", "DET": "DET", "GB": "GB", "MIN": "MIN",
    "CAR": "CAR", "NO": "NO", "TB": "TB", "LAR": "LAR", "SEA": "SEA", "SF": "SF",
    # AFC
    "BUF": "BUF", "MIA": "MIA", "NE": "NE", "NYJ": "NYJ",
    "BAL": "BAL", "CIN": "CIN", "CLE": "CLE", "PIT": "PIT",
    "HOU": "HOU", "IND": "IND", "JAX": "JAX", "TEN": "TEN",
    "DEN": "DEN", "KC": "KC", "LAC": "LAC", "LV": "LV",
    # PFR quirk codes sometimes seen historically:
    "GNB": "GB", "KAN": "KC", "NWE": "NE", "SDG": "LAC", "STL": "LAR", "OAK": "LV",
}

# Home-field values (points). Tweak to taste.
DEFAULT_HFA: Dict[str, float] = {
    "ARI": 1.4, "ATL": 1.5, "BAL": 1.6, "BUF": 1.7, "CAR": 1.4, "CHI": 1.5,
    "CIN": 1.6, "CLE": 1.6, "DAL": 1.5, "DEN": 2.0, "DET": 1.7, "GB": 1.8,
    "HOU": 1.4, "IND": 1.5, "JAX": 1.3, "KC": 1.9, "LV": 1.2, "LAC": 0.5,
    "LAR": 0.8, "MIA": 1.5, "MIN": 1.6, "NE": 1.4, "NO": 1.7, "NYG": 1.2,
    "NYJ": 1.2, "PHI": 1.7, "PIT": 1.6, "SF": 1.5, "SEA": 1.8, "TB": 1.4,
    "TEN": 1.4, "WAS": 1.3,
}

# Blending weights
W_NFELO = 0.70
W_SRS = 0.30

app = FastAPI(title="NFL Power Ratings (Blended, Daily)")
templates = Jinja2Templates(directory="templates")

# ----------------------------
# Scrapers & transforms
# ----------------------------
def fetch_nfelo_table() -> pd.DataFrame:
    """Scrape nfelo Elo table -> DataFrame(team, elo)."""
    # Try read_html first
    for url in TARGET_URLS:
        try:
            tables = pd.read_html(url, flavor="bs4")
            for t in tables:
                cols = [c.lower() for c in t.columns.astype(str)]
                if any("elo" in c for c in cols) and any("team" in c for c in cols):
                    df = t.copy()
                    df.columns = [c.lower() for c in df.columns.astype(str)]
                    team_col = [c for c in df.columns if "team" in c][0]
                    elo_col = [c for c in df.columns if "elo" in c][0]
                    out = df[[team_col, elo_col]].rename(columns={team_col: "team", elo_col: "elo"})
                    out["team"] = out["team"].astype(str)
                    out["elo"] = pd.to_numeric(out["elo"], errors="coerce")
                    out = out.dropna(subset=["elo"])
                    if len(out) >= 28:
                        return out
        except Exception:
            pass

    # Fallback: heuristic parse
    for url in TARGET_URLS:
        try:
            html = requests.get(url, timeout=20).text
            soup = BeautifulSoup(html, "html.parser")
            candidates = []
            for tag in soup.find_all(text=True):
                txt = " ".join(tag.strip().split())
                if not txt:
                    continue
                for name in TEAM_ALIASES.keys():
                    if name in txt:
                        parent = tag.parent
                        window_text = " ".join(parent.get_text(" ").split())
                        nums = [int(s) for s in window_text.split() if s.isdigit()]
                        nums = [n for n in nums if 1300 <= n <= 1850]
                        if nums:
                            candidates.append((name, max(nums)))
            if candidates:
                df = pd.DataFrame(candidates, columns=["team", "elo"]).drop_duplicates("team")
                if len(df) >= 28:
                    return df
        except Exception:
            pass

    raise RuntimeError("Could not fetch nfelo Elo table.")


def elo_to_point_power(df: pd.DataFrame) -> pd.DataFrame:
    league_avg = df["elo"].mean()
    df = df.copy()
    df["power_nfelo"] = (df["elo"] - league_avg) / ELO_TO_POINTS_DIVISOR
    return df


def normalize_nfelo(df: pd.DataFrame) -> pd.DataFrame:
    df = df[df["team"].isin(TEAM_ALIASES.keys())].copy()
    df["code"] = df["team"].map(TEAM_ALIASES)
    return df[["code", "team", "elo", "power_nfelo"]]


def fetch_pfr_srs(season: Optional[int] = None) -> pd.DataFrame:
    """Scrape PFR season SRS table -> DataFrame(code, team, srs)."""
    season = season or PFR_SEASON_DEFAULT
    url = f"https://www.pro-football-reference.com/years/{season}/"
    tables = pd.read_html(url, flavor="lxml")
    candidate = None
    for t in tables:
        cols = [c.lower() for c in t.columns.astype(str)]
        if "srs" in cols and any(c in cols for c in ["tm", "team", "teamname"]):
            candidate = t.copy()
            break
    if candidate is None:
        raise RuntimeError("Could not find SRS table on PFR.")

    candidate.columns = [str(c).strip().lower() for c in candidate.columns]
    team_col = "tm" if "tm" in candidate.columns else "team"
    df = candidate[[team_col, "srs"]].rename(columns={team_col: "pfr_team"})

    def map_code(x: str) -> Optional[str]:
        x = str(x).strip().upper()
        if x in PFR_ABBR_TO_CODE:
            return PFR_ABBR_TO_CODE[x]
        for name, code in TEAM_ALIASES.items():
            if x in name.upper() or name.upper() in x:
                return code
        return None

    df["code"] = df["pfr_team"].apply(map_code)
    df = df.dropna(subset=["code"]).copy()
    df["srs"] = pd.to_numeric(df["srs"], errors="coerce")
    df = df.dropna(subset=["srs"])
    name_by_code = {v: k for k, v in TEAM_ALIASES.items()}
    df["team"] = df["code"].map(name_by_code)
    return df[["code", "team", "srs"]]


def build_blended_payload(season_for_srs: Optional[int] = None) -> Dict:
    nfelo = fetch_nfelo_table()
    nfelo = elo_to_point_power(nfelo)
    nfelo = normalize_nfelo(nfelo)

    pfr = fetch_pfr_srs(season_for_srs)

    merged = pd.merge(nfelo, pfr[["code", "srs"]], on="code", how="left")
    merged["srs"].fillna(0.0, inplace=True)
    valid_srs = merged["srs"].abs().sum() > 0.0
    w_srs = W_SRS if valid_srs else 0.0
    merged["power_blended"] = (W_NFELO * merged["power_nfelo"]) + (w_srs * merged["srs"])

    now_et = datetime.now(TZ).strftime("%Y-%m-%d %H:%M:%S %Z")
    out = []
    for _, r in merged.iterrows():
        code = r["code"]
        out.append({
            "team": r["team"],
            "code": code,
            "elo": round(float(r["elo"]), 1),
            "power_nfelo": round(float(r["power_nfelo"]), 2),
            "srs": round(float(r["srs"]), 2),
            "power": round(float(r["power_blended"]), 2),
            "hfa": float(DEFAULT_HFA.get(code, 1.5)),
        })
    out.sort(key=lambda x: x["power"], reverse=True)
    return {
        "last_updated_et": now_et,
        "blend": {"nfelo": W_NFELO, "srs": w_srs},
        "method": f"power = {W_NFELO}*nfelo_points + {w_srs}*SRS",
        "ratings": out
    }


def update_data() -> Dict:
    payload = build_blended_payload(PFR_SEASON_DEFAULT)
    with open(DATA_PATH, "w") as f:
        json.dump(payload, f, indent=2)
    return payload


def load_data() -> Dict:
    try:
        with open(DATA_PATH, "r") as f:
            return json.load(f)
    except Exception:
        return update_data()

# ----------------------------
# Week schedule (PFR weekly page)
# ----------------------------
def fetch_pfr_week_matchups(season: int, week: int) -> List[Tuple[str, str, bool]]:
    """Return (home_code, away_code, is_neutral) for season/week via PFR."""
    url = f"https://www.pro-football-reference.com/years/{season}/week_{week}.htm"
    tables = pd.read_html(url, flavor="lxml")
    candidate = None
    for t in tables:
        cols = [str(c).lower() for c in t.columns]
        if any("visitor" in c for c in cols) and any("home" in c for c in cols):
            candidate = t
            break
    if candidate is None:
        raise RuntimeError("Could not find weekly schedule table on PFR.")

    df = candidate.copy()
    df.columns = [str(c).strip() for c in df.columns]
    vis_col = next((c for c in df.columns if c.lower() in ["visitor", "vistm", "visitor/team"]), None)
    home_col = next((c for c in df.columns if c.lower() in ["home", "hometm", "home/team"]), None)
    if not vis_col or not home_col:
        raise RuntimeError("Unrecognized weekly schedule layout.")

    def to_code(x: str) -> Optional[str]:
        x = str(x).strip().upper()
        return PFR_ABBR_TO_CODE.get(x)

    neutral_col = next((c for c in df.columns if "neutral" in c.lower()), None)
    location_col = next((c for c in df.columns if "location" in c.lower()), None)

    matchups = []
    for _, row in df.iterrows():
        away_abbr = to_code(row[vis_col])
        home_abbr = to_code(row[home_col])
        if not away_abbr or not home_abbr:
            continue
        is_neutral = False
        if neutral_col and str(row.get(neutral_col, "")).strip().lower() in ("yes", "1", "true"):
            is_neutral = True
        elif location_col:
            loc = str(row.get(location_col, "")).lower()
            if any(k in loc for k in ["london", "frankfurt", "munich", "mexico", "wembley", "tottenham", "allianz", "azteca"]):
                is_neutral = True
        matchups.append((home_abbr, away_abbr, is_neutral))
    return matchups

# ----------------------------
# Scheduler (daily 9:15am ET)
# ----------------------------
scheduler = BackgroundScheduler(timezone=TZ)
scheduler.add_job(update_data, CronTrigger(hour=9, minute=15))
scheduler.start()

# ----------------------------
# Routes
# ----------------------------
@app.get("/", response_class=HTMLResponse)
def dashboard(request: Request):
    data = load_data()
    return templates.TemplateResponse(
        "index.html",
        {
            "request": request,
            "updated": data["last_updated_et"],
            "blend": data["blend"],
            "ratings": data["ratings"],
        },
    )

@app.get("/ratings")
def get_ratings():
    return JSONResponse(load_data())

@app.get("/ratings.csv", response_class=PlainTextResponse)
def get_ratings_csv():
    data = load_data()
    df = pd.DataFrame(data["ratings"])[["team","code","power","power_nfelo","srs","hfa","elo"]]
    return df.to_csv(index=False)

@app.get("/refresh")
def refresh():
    try:
        payload = update_data()
        return JSONResponse({"status": "ok", "updated": payload["last_updated_et"], "blend": payload["blend"]})
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))

@app.get("/line")
def line(
    home: str = Query(..., description="Home team code, e.g., DET"),
    away: str = Query(..., description="Away team code, e.g., MIN"),
    neutral: int = Query(0, description="1 for neutral site (no HFA)"),
):
    data = load_data()
    by_code = {r["code"]: r for r in data["ratings"]}
    if home not in by_code or away not in by_code:
        raise HTTPException(status_code=400, detail="Unknown team code(s). Use codes like KC, SF, DET, MIN.")
    rh, ra = by_code[home], by_code[away]
    base = rh["power"] - ra["power"]
    hfa = 0.0 if neutral == 1 else rh["hfa"]
    proj = base + hfa
    return {
        "home": home,
        "away": away,
        "neutral_site": bool(neutral == 1),
        "calc": f"({rh['power']:.2f} - {ra['power']:.2f}) + {hfa:.2f}",
        "projected_spread_home": round(proj, 2)
    }

@app.get("/week-lines")
def week_lines(
    season: int = Query(PFR_SEASON_DEFAULT, description="Season (e.g., 2025)"),
    week: int = Query(..., description="Week number (e.g., 3)"),
):
    data = load_data()
    ratings = {r["code"]: r for r in data["ratings"]}
    try:
        games = fetch_pfr_week_matchups(season, week)
    except Exception as e:
        raise HTTPException(status_code=500, detail=f"Schedule fetch failed: {e}")

    results = []
    for home, away, neutral in games:
        if home not in ratings or away not in ratings:
            continue
        rh, ra = ratings[home], ratings[away]
        base = rh["power"] - ra["power"]
        hfa = 0.0 if neutral else rh["hfa"]
        proj = base + hfa
        results.append({
            "home_team": rh["team"], "home": home,
            "away_team": ra["team"], "away": away,
            "neutral_site": bool(neutral),
            "calc": f"({rh['power']:.2f} - {ra['power']:.2f}) + {hfa:.2f}",
            "projected_spread_home": round(proj, 2)
        })
    results.sort(key=lambda r: abs(r["projected_spread_home"]), reverse=True)
    return {"season": season, "week": week, "blend": data["blend"], "lines": results}
