# NFL Power Ratings (Blended, Daily)

This project serves NFL **power ratings** with a simple HTML dashboard, a JSON/CSV API, and endpoints to project lines (single games and full week slates).

## Features
- Daily auto-update @ **9:15 AM ET** (nfelo Elo scraped + Pro-Football-Reference SRS).
- **Blended power** = 70% nfelo points + 30% SRS (SRS weight drops to 0 if not available early season).
- Root path `/` shows a searchable, sortable table.
- `/ratings`, `/ratings.csv`, `/line?home=KC&away=BUF`, `/week-lines?season=2025&week=3`.

## Run locally
```bash
pip install -r requirements.txt
python -m uvicorn app:app --host 0.0.0.0 --port 8000
```

## Deploy options
- **GitHub Codespaces (Codex)**: open in Codespaces, it will detect Python, then run the above commands.
- **Render/Heroku-ish**: add a Procfile `web: uvicorn app:app --host 0.0.0.0 --port $PORT`.
- **Docker**: use the included Dockerfile.
